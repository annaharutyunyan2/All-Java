package gameOfLife;

import java.util.Scanner;

public class ArrayLife {
    private String name;
    private String author;
    private int width;
    private int height;
    private int startUpperCol;
    private int startUpperRow;
    private String cells;
    private boolean[][] world;

    public ArrayLife(String input){
        String[] splitedArr = formatString(input);
        this.name = splitedArr[0];
        this.author = splitedArr[1];
        this.width = Integer.parseInt(splitedArr[2]);
        this.height = Integer.parseInt(splitedArr[3]);
        this.world = new boolean[this.width][this.height];
        // this.startUpperCol = Integer.parseInt(splitedArr[4]);
        // this.startUpperRow = Integer.parseInt(splitedArr[5]);
        this.cells = splitedArr[6];
        String[] split = splitString(cells);
        for(int i=0; i < split.length; i++){
            for(int j=0; j < split[i].length(); j++){
                int k;
                for(this.startUpperCol = Integer.parseInt(splitedArr[4]), this.startUpperRow = Integer.parseInt(splitedArr[5]), k=0;
                    k < booleanArray(split[i]).length; k++, this.startUpperCol++, this.startUpperRow++){
                    world[this.startUpperRow][this.startUpperCol] = booleanArray(split[i])[k];
                }
            }
        }
    }


    private String[] formatString(String st){
        return st.split(":");
    }

    private boolean[] booleanArray(String booleanSt){
        boolean[] booleanArr = new boolean[booleanSt.length()];
        for(int i=0; i < booleanArr.length; i++){
            if(booleanSt.charAt(i) == '0'){
                booleanArr[i] = false;
            }
            else if(booleanSt.charAt(i) == '1'){
                booleanArr[i] = true;
            }
            else {
                System.exit(0);
            }
        }
        return booleanArr;
    }

    private String[] splitString(String booleanString){
        return booleanString.split(" ");
    }


    public boolean getCell(int col, int row) {
        if (row < 0 || row >= height) {
            return false;
        }
        if (col < 0 || col >= width) {
            return false;
        }
        return world[row][col];
    }

    public void setCell(int col, int row, boolean value){
        world[row][col] = value;
    }

    public void print(){
        for(int i=0; i < world.length; i++){
            for(int j=0; j < world[i].length; j++){
                System.out.println(world[i][j] + " ");
            }
            System.out.println();
        }
    }

    public int countNeighbours(int col, int row){
        int numberOfAliveMembers = 0;
        for(int i = row-1; i <= row+1; i++){
            for(int j = col-1; j <= col+1; j++){
                if(i != row || j != col){
                    if(world[i][j] == true){
                        numberOfAliveMembers++;
                    }
                }
            }
        }
        return numberOfAliveMembers;
    }

    public boolean computeCell(int col, int row){
        if(world[row][col] == true){
            if(countNeighbours(row, col) != 2 && countNeighbours(row, col) != 3){
                world[row][col] = false;
            }
        }
        else {
            if(countNeighbours(row, col) == 3){
                world[row][col] = true;
            }
        }
        return world[row][col];
    }

    public void nextGeneration() {
        for (int i=0; i < height; i++) {
            for (int j=0; j < width; j++) {
                if (computeCell(j, i))
                    world[i][j] = true;
                else
                    world[i][j] = false;
            }
        }
    }

    public void play(){
        Scanner sc = new Scanner(System.in);
        char keyboard = sc.next().charAt(0);
        while(keyboard == 's'){
            print();
            nextGeneration();

        };
        if(keyboard == 's'){
            System.exit(0);
        }
        // while(true){
        //     if(keyboard == 's'){
        //         print();
        //         nextGeneration();
        //     }
        //     else if(keyboard == 'q'){
        //         System.exit(0);
        //     }
        // }
    }
}
