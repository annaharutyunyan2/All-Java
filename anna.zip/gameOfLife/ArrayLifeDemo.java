package gameOfLife;

public class ArrayLifeDemo {
    public static void main(String[] args){
        ArrayLife a1 = new ArrayLife(args[0]);
        a1.play();
    }
}

