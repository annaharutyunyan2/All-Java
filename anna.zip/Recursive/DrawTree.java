package Recursive;

import java.applet.Applet;
import java.awt.*;

public class DrawTree extends Applet {
    public void init(){
        setBackground(Color.black);
        setSize(600, 400);
    }
    public void paint(Graphics g){
        drawTree(g, Color.yellow, 300, 600, -90, 7);
        drawTree(g, Color.magenta, 400, 600, -70, 5);
    }

    public void drawTree(Graphics xg, Color guyn, int x1, int y1, int a, int n){
        if (n == 0){
            return;
        }
//        int x2 = x1 - 10 * n;
//        int y2 = y1 - 10 * n ;
        int x2 = x1 + (int)(10 * n * Math.cos(Math.toRadians(a)));
        int y2 = y1 + (int)(10 * n * Math.sin(Math.toRadians(a)));
        xg.setColor(guyn);
        if(n < 5){
            xg.drawString("*", x2, y2);
        }
        xg.setColor(Color.green);
        xg.drawLine(x1, y1, x2, y2);
        drawTree(xg, guyn, x2, y2, a - 10, n - 1);
        drawTree(xg, guyn, x2, y2, a + 30, n - 1);
        drawTree(xg, guyn, x2, y2, a - 20, n - 1);
        drawTree(xg, guyn, x2, y2, a - 40, n - 1);
    }
}
