package Recursive;

public class RecursiveFunction {
    public static double chain(int n){
        if(n == 1){
            return 1;
        }
        return 1 + 1/chain(n - 1);
    }
    public static int f(int n){
        if(n == 1){
            return 1;
        }
        return n * f(n-1);
    }
    public static void main(String[] args) {
        System.out.println(chain(100));
    }
}
