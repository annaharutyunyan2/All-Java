package geometry;

public class Circle {
    int x;
    int y;
    int r;

    Circle(){
    }

    Circle(int x, int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
    }
}
