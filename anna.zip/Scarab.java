package geometry;

import java.applet.Applet;
import java.awt.*;

public class Scarab extends Applet {
    public void paint(Graphics vanGogh) {
        vanGogh.setColor(Color.red);
        vanGogh.drawLine(0, 0, 100, 100);
        for(int i = 0; i < 50; i++){
            vanGogh.setColor(Color.red);
            vanGogh.drawLine(0, 0, 100, i);
        }
    }
}
