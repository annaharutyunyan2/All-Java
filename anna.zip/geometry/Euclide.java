package geometry;

public class Euclide {
    public static void main(String[] args) {
        Circle kapuytOxak = new Circle(100, 100, 75);
    }
}
