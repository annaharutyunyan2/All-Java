package geometry;
import java.awt.*;

public class Circle {
    public int x;
    public int y;
    public int r;
    public String name;
    public Color color;
    public int life;

    Circle(){
        x = 0;
        y = 0;
        r = 100;
    }

    Circle(int x, int y, int r){
        this.x = x;
        this.y = y;
        this.r = r;
    }
    Circle(int x, int y, int r, String name){
        this.x = x;
        this.y = y;
        this.r = r;
        this.name = name;
    }
    Circle(int x, int y, int r, String name, Color color){
        this.x = x;
        this.y = y;
        this.r = r;
        this.name = name;
        this.color = color;
    }
    public Circle(int x, int y, int r, String name, Color color, int life){
        this.x = x;
        this.y = y;
        this.r = r;
        this.name = name;
        this.color = color;
        this.life = life;
    }

    public void setX(int ax){
        x = ax;
    }
    public int getX(){
        return x;
    }
}
