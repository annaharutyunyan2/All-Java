package geometry;

import java.applet.Applet;
import java.awt.*;

public class Rectangle extends Applet {
    int x0;
    int y0;
    int h;
    int w;
    int arrayX[] = {0, 400, 400};
    int arrayY[] = {0, 400, 0};
    Color karmirGuyn;
    Dimension chap;
    public void init(){
        setBackground(Color.gray);
        setForeground(Color.CYAN);
        chap = new Dimension(700, 500);
        this.setSize(chap);
//        paintbrush.fillPolygon(arrayX, arrayY, 3);
        x0 = 100;
        y0 = 150;
        h = 75;
        w = 300;
        System.out.println("init");
    }
    public void paint(Graphics paintbrush) {
        paintbrush.setColor(Color.red);
        paintbrush.fillRect(0, 0, 100, 100);
        paintbrush.setColor(Color.blue);
        paintbrush.fillRoundRect(10, 10, 80, 80, 13, 10);
        paintbrush.setColor(Color.yellow);
        paintbrush.fill3DRect(20, 20, 60, 60, true);
        paintbrush.fillOval(30, 30, 100, 50);
        paintbrush.setColor(Color.red);
        paintbrush.fillArc(50, 50, 100 ,50, 0, 90);



        System.out.println("Paint");
        paintbrush.setColor(Color.blue);
        for(int i = 0; i < h; i++){
            karmirGuyn = new Color(255 - 2 * i, 0, 0);
            paintbrush.setColor(karmirGuyn);
            paintbrush.drawLine(x0, y0 + i, x0 + w, y0 + i);
            Color kapuytGuyn = new Color(0, 0, 255 - 2 * i);
            paintbrush.setColor(kapuytGuyn);
            paintbrush.drawLine(x0, y0 + i + h, x0 + w, y0 + i + h);
            Color ciranaguyn = new Color(0, 255 - 2 * i, 255 - 2 * i);
            paintbrush.setColor(ciranaguyn);
            paintbrush.drawLine(x0, y0 + i + 2 * h, x0 + w, y0 + i + 2 * h);
        }
        Font mec = new Font("Arial",2,25);
        paintbrush.setFont(mec);
        paintbrush.drawString("Armenia", x0 + w / 3, y0 - h / 5);
    }
    public void start(){
        System.out.println("Start");
    }
    public void stop(){
        System.out.println("Stop");
    }
    public void destroy(){
        System.out.println("Destroy");
    }
}

