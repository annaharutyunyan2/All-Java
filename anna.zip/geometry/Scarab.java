package geometry;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Scarab extends Applet implements MouseMotionListener, MouseListener {
    int x0;
    int y0;
    int r0;
    int w;
    long startTime;
    long endTime;
    Circle ra;
    Circle os;
    Color karmirGuyn;
    Dimension chap;
    Font mec;
    boolean collision;
    Point p1;
    Point p2;
    Point points[] = new Point[20];
    int k;
    public void init(){
        setBackground(Color.black);
        setForeground(Color.CYAN);
        chap = new Dimension(700, 500);
        this.setSize(chap);
        x0 = 0;
        y0 = 100;
        r0 = 75;
        w = 300;
        collision = false;
        startTime = System.currentTimeMillis();
        System.out.println(startTime);
        p1 = new Point(0, 0);
        p2 = new Point(0, 0);
        for(int i = 0; i < points.length; i++){
            points[i] = p2;
        }
        k = 0;
        System.out.println("init");
        ra = new Circle(x0, y0 , r0, "Ra", Color.red, 100);
        os = new Circle(x0 + 300, y0, r0 - 20, "Os", Color.blue, 100);
        mec = new Font("Arial",2,25);
//        addMouseMotionListener(this);
        addMouseListener(this);
    }
    public void drawObject(Circle c, Graphics g){
        g.setFont(mec);
        g.setColor(c.color);
        g.drawString(c.name, c.x, c.y);
        g.setColor(c.color);
        g.fillOval(c.x - c.r, c.y - c.r, 2 * c.r, 2 * c.r);
        g.setColor(Color.magenta);
        g.fillRect(c.x - c.r, c.y - c.r, ((2 * c.r) * c.life ) / 100, 7);
    }
    public void paint(Graphics g) {
        drawObject(os, g);
        drawObject(ra, g);
//        g.setXORMode();
//        ra.x++;
        int d = distance(ra, os);
        endTime = System.currentTimeMillis();
        System.out.println((endTime - startTime) / 1000);
        collision = collide(ra, os);
        g.setColor(Color.cyan);
        g.drawString("h = " + d, 350, 20);
        if (collision) {
            g.drawString("baxum", 350, 40);
            if (ra.r < os.r && ra.r >= 0) {
                ra.r = ra.r - 8;
                os.r += 4;
                ra.life -= 8;
            } else {
                if (os.r >= 0) {
                    ra.r += 4;
                    os.r -= 8;
                    os.life -= 8;
                }
            }
            g.setColor(Color.yellow);
//        g.drawLine(p1.x, p1.y, p2.x, p2.y);
            for (int i = 0; i < k; i++) {
                System.out.println(points[i].x + " " + points[i].y);
                g.drawLine(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
            }
//        for(int i = 0; i < 5; i++){
//            g.setColor(Color.red);
//            g.drawLine(0, i, 500, i);
//        }
        }
        try{
            Thread.sleep(1000);
        }catch(Exception e){
        }
        repaint();
    }
    public boolean collide(Circle c1, Circle c2){
        if(distance(c1,c2) == (c1.r + c2.r)){
            return true;
        }else{
            return false;
        }
    }
    public int distance(Circle c1, Circle c2){
        int d = (int)Math.sqrt((c2.x - c1.x) * (c2.x - c1.x) + (c2.y - c1.y) * (c2.y - c1.y));
        return d;
    }
    public void mouseDragged(MouseEvent e) {
        ra.x = e.getX();
        ra.y = e.getY();
//        repaint();
    }
    public void mouseMoved(MouseEvent e) {

    }
    public void mouseClicked(MouseEvent e) {
        p2.x = e.getX();
        p2.y = e.getY();
        points[k] = p2;
        k++;
        repaint();
    }
    public void mousePressed(MouseEvent e) {
//        p1.x = e.getX();
//        p1.y = e.getY();
//        points[k] = p1;
//        k++;
    }
    public void mouseReleased(MouseEvent e) {

    }
    public void mouseEntered(MouseEvent e) {

    }
    public void mouseExited(MouseEvent e) {

    }
}
