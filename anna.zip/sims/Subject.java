package sims;

public class Subject {
    String name;
    Lecturer lecturer;

    Subject(){

    }
    Subject(String name){
        this.name = name;
    }

    Subject(String name, Lecturer lecturer){
        this.name = name;
        this.lecturer = lecturer;
    }
}
