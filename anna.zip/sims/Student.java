package sims;

public class Student {
    String firstName;
    String lastName;
    int age;
    long id;
    char grade;
    boolean smart;
    Address address;
    Subject subject[];

    static String university;

    Student(){
    }
    Student(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }
    Student(String firstName, String lastName, int age, long id, char grade, boolean smart, Address address){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.id = id;
        this.grade = grade;
        this.smart = smart;
        this.address = address;
    }
    Student(Subject subject[]){
        this.subject = subject;
    }

//    Student(String firstName, String lastName){
//        this.firstName = firstName;
//        this.lastName = lastName;
//    }

    public void fullName(){
        S.tpel(firstName + " " + lastName);
    }

    public boolean isSmart(){
        return smart;
    }
    public void printInfo(){
        S.tpel(firstName + " " + lastName + " " + university + " " + age + " " + id + " " + grade + " " + smart);
    }
}
