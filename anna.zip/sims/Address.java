package sims;

public class Address {
    String country;
    String city;
    String street;
    String apartment;

    Address(){

    }

    Address(String xCountry, String xCity, String xStreet, String xApartment){
        country = xCountry;
        city = xCity;
        street = xStreet;
        apartment = xApartment;
    }
}
