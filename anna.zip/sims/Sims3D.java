package sims;

public class Sims3D {
    public static void main(String[] args) {
        Subject math = new Subject("Matematika");
        Subject physics = new Subject("Fizika");
        Subject english = new Subject("Angleren");
        Subject ararkaner[] = {math, physics, english};
        Subject ararkaner2[] = {ararkaner[0], ararkaner[1]};

        Student anna = new Student();
        anna.firstName = "Anna";
        anna.lastName = "Harutyunyan";
        anna.age = 17;
        anna.university = "AuA";
        anna.fullName();
        anna.printInfo();
        anna.subject = ararkaner;
        S.tpel(anna.firstName);

        Student tigran = new Student();
        tigran.firstName = "Tigran";
        tigran.university = "AUA";
        tigran.printInfo();

        Student gagik = new Student("Gagik", "Sargsyan");
        gagik.subject = ararkaner2;
        gagik.university = "YSU";
        gagik.printInfo();
        anna.printInfo();
        String text = anna.university;
        String textA = Student.university;

        Address aniHasce = new Address("Armenia", "Yerevan", "hndgnd", "22");
        Student ani = new Student("Ani", "dhsjhfdshjc", 43, 3254463528l, 'F', true, aniHasce);
        System.out.println(ani.address.country + ani.address.city);
    }
}
