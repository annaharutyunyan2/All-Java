package sims;

public class S {
    public static void tpel(int a){
        System.out.print(a);
    }
    public static void tpel(String a){
        System.out.print(a);
    }
    public static void tpel(char a){
        System.out.print(a);
    }
    public static void tpel(Object a){
        System.out.print(a);
    }
}
