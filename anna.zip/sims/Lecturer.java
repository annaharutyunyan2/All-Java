package sims;

public class Lecturer {
    String fullName;
}
