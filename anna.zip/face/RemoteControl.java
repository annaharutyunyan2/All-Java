package face;

public interface RemoteControl {
    public void play();
    public void stop();
    public void next();
    public void prev();
}
