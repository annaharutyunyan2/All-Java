package face;

public class TV implements RemoteControl{
    int channel;
    boolean smart;

    TV(int channel){
        this.channel = channel;
    }
    public void printChannel(){
        System.out.println(channel);
    }
    public void play(){
        for(int i = 0; i <= 100; i++){
            channel++;
        }
    }
    public void stop(){
        channel = 0;
    }
    public void next(){
        channel++;
    }
    public void prev(){
        channel--;
    }
}


