package face;

public class Piano {
        String note;

        Piano(String note){
            this.note = note;
        }
        public void printNote(){
            System.out.println(note);
        }


}

