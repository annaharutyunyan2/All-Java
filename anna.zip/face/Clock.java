package face;

public class Clock implements RemoteControl{
        int jam;

        Clock(int jam){
            this.jam = jam;
        }
        public void printJam(){
            System.out.println(jam);
        }

    public void play(){
        for(int i = 0; i <= 100; i++){
            jam++;
        }
    }
    public void stop(){
        jam = 0;
    }
    public void next(){
        jam++;
    }
    public void prev(){
        jam--;
    }
    }

