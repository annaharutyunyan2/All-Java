package face;

import geometry.Circle;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class MouseTest extends Applet implements MouseMotionListener {
    int x;
    int y;
    Font mec;
    Circle ra;
    Circle os;
    long startTime;
    long endTime;
    int random;
    int randomOs;
    boolean up;
    boolean down;
    boolean right;
    boolean left;
    public void init(){
        up = false;
        down = false;
        right = false;
        left = false;
        x = 100;
        y = 100;
        mec = new Font("Arial", Font.BOLD, 25);
        setBackground(Color.black);
        setForeground(Color.CYAN);
        startTime = System.currentTimeMillis();
        addMouseMotionListener(this);
        System.out.println("init");
        ra = new Circle(250, 250 , 150, "Ra", Color.red, 100);
        os = new Circle(150, 350 , 150, "Os", Color.yellow, 100);
    }

    public void start(){
        System.out.println("start");
    }

    public void paint(Graphics g){
        g.setFont(mec);
        g.drawString("Anna", x, y);
//        System.out.println("paint");
        drawObject(ra, g);
        g.setXORMode(Color.black);
        drawObject(os, g);
        endTime = System.currentTimeMillis();
        try{
            Thread.sleep(10);
        }catch(Exception e){
        }
//        System.out.println(random);
        long delta = ((endTime - startTime) / 100);
        if(delta % 10 == 3) {
            random = (int)(4 * Math.random() + 1);
            System.out.println(delta + "1111111111111111");
        }
        if(delta % 10 == 7) {
            randomOs = (int)(4 * Math.random() + 1);
            System.out.println(delta + "2222222222222222");
        }
        move(random, ra);
        move(randomOs, os);
//        switch(random){
//            case 1: ra.x++; break;
//            case 2: ra.y++; break;
//            case 3: ra.x--; break;
//            case 4: ra.y--; break;
//        }
//        ra.x++;
        repaint();
    }

    public void mouseDragged(MouseEvent e){
//        System.out.println("Mouse Dragged");
//        System.out.println(e.getX());
        x = e.getX();
        y = e.getY();
        repaint();
    }
    public void mouseMoved(MouseEvent e){
//        System.out.println("Mouse Moved" + " " + x++);
        x = e.getX();
        y = e.getY();
        repaint();
    }

    public void stop(){
        System.out.println("stop");
    }

    public void destroy(){
        System.out.println("destroy");
    }

    public void drawObject(Circle c, Graphics g){
        g.setFont(mec);
        g.setColor(c.color);
        g.drawString(c.name, c.getX(), c.y);
        g.setColor(c.color);
        g.fillOval(c.getX() - c.r, c.y - c.r, 2 * c.r, 2 * c.r);
        g.setColor(Color.magenta);
        g.fillRect(c.getX() - c.r, c.y - c.r, ((2 * c.r) * c.life ) / 100, 7);
    }

    public void move(int x, Circle c){
        switch(x){
            case 1: c.x++; break;
            case 2: c.y++; break;
            case 3: c.x--; break;
            case 4: c.y--; break;
        }
    }

}
